<template>
  <div class="product">
    <div class="list">
      <img src="../assets/xm.png" alt="">
      <div class="tit">云思顿智能垃圾整理系统及其解决方案<p class="active">已获投资</p></div>
      <p class="school">南京工业职业技术学院<span>江苏省</span></p>
      <div class="tag"><span>制造业</span><span>制造业</span><span>制造业</span></div>
      <p class="introduce">现如今，互联网直播已经在人类的日常生活中普及开来，现在在互联网上随时可见各种类型的直播，室内直播，室外直播，室内直播包括各种见各种类型的直播，室内直播，室外直播，室内直播包括各种室现如今，互联网直播已经在人类的日常生活中普及开来，现在在互联网上随时可见各种类型的直播，室内直播，室外直播，室内直播包括各种室</p>
    </div>
    <div class="list">
      <img src="../assets/xm.png" alt="">
      <div class="tit">云思顿智能垃圾整理系统及其解决方案<p>已获投资</p></div>
      <p class="school">南京工业职业技术学院<span>江苏省</span></p>
      <div class="tag"><span>制造业</span><span>制造业</span><span>制造业</span></div>
      <p class="introduce">现如今，互联网直播已经在人类的日常生活中普及开来，现在在互联网上随时可见各种类型的直播，室内直播，室外直播，室内直播包括各种见各种类型的直播，室内直播，室外直播，室内直播包括各种室现如今，互联网直播已经在人类的日常生活中普及开来，现在在互联网上随时可见各种类型的直播，室内直播，室外直播，室内直播包括各种室</p>
    </div>
    <div class="list">
      <img src="../assets/xm.png" alt="">
      <div class="tit">云思顿智能垃圾整理系统及其解决方案<p>已获投资</p></div>
      <p class="school">南京工业职业技术学院<span>江苏省</span></p>
      <div class="tag"><span>制造业</span><span>制造业</span><span>制造业</span></div>
      <p class="introduce">现如今，互联网直播已经在人类的日常生活中普及开来，现在在互联网上随时可见各种类型的直播，室内直播，室外直播，室内直播包括各种见各种类型的直播，室内直播，室外直播，室内直播包括各种室现如今，互联网直播已经在人类的日常生活中普及开来，现在在互联网上随时可见各种类型的直播，室内直播，室外直播，室内直播包括各种室</p>
    </div>
    <div class="page">
      <el-pagination background layout="prev, pager, next" :total="1000"></el-pagination>
    </div>
  </div>
</template>

<script>
export default {
  
}
</script>

<style scoped>
.product .list{height: 259px;padding: 40px 0;border-top: 1px dashed #c6c6c6;}
.product .list:first-child{border: none;}
.product .list img{float: left;width: 178px;height: 178px;border-radius: 3px;margin-right: 25px;}
.product .list .tit{font-size: 25px;color: #1b1b1b;line-height: 26px;font-weight: 600;}
.product .list .tit p{display: inline-block;font-size: 16px;color: #fff;background-color: #ccc;padding: 0 10px;vertical-align: 8%;border-radius: 3px;margin-left: 20px;font-weight: normal;}
.product .list .tit .active{background-color: #eb8710;}
.product .list .school{font-size: 16px;font-weight: 600;color: #333;margin-top: 6px;}
.product .list .school span{margin-left: 60px;}
.product .list .tag{margin: 17px 0;line-height: 24px;}
.product .list .tag span{display: inline-block;font-size: 15px;color: #888;border: 1px solid #e0e0e0;border-radius: 3px;margin-right: 30px;padding: 0 20px;}
.product .list .introduce{font-size: 15px;color: #666;line-height: 22px;}
.product .page{width: 440px;margin: 20px auto;}
</style>